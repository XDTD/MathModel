              precision    recall  f1-score   support
    
       <=50k       0.91      0.95      0.93      7712
        >50k       0.67      0.49      0.57      1495
    
    accuracy                           0.88      9207
   macro avg       0.79      0.72      0.75      9207
weighted avg       0.87      0.88      0.87      9207

roc: 0.9042137345786091