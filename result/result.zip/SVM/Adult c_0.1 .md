D:\Anaconda3\envs\tf\python.exe E:/CODE/GIT/MathModel/pa2_svm.py
D:\Anaconda3\envs\tf\lib\site-packages\sklearn\svm\base.py:193: FutureWarning: The default value of gamma will change from 'auto' to 'scale' in version 0.22 to account better for unscaled features. Set gamma explicitly to 'auto' or 'scale' to avoid this warning.
  "avoid this warning.", FutureWarning)
              precision    recall  f1-score   support

       <=50k       0.90      0.96      0.93      7654
        >50k       0.69      0.47      0.56      1553
    
    accuracy                           0.87      9207
   macro avg       0.79      0.71      0.74      9207
weighted avg       0.86      0.87      0.86      9207

roc: 0.9040680638517357

Process finished with exit code 0