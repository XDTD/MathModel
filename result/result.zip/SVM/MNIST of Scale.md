D:\Anaconda3\envs\tf\python.exe E:/CODE/GIT/MathModel/SvmTest.py
*
optimization finished, #iter = 872
nu = 0.097807
obj = -796.617278, rho = -0.877492
nSV = 1149, nBSV = 1069
*
optimization finished, #iter = 874
nu = 0.095455
obj = -749.981659, rho = -1.579710
nSV = 1114, nBSV = 1037
*
optimization finished, #iter = 597
nu = 0.063136
obj = -532.370095, rho = -1.862447
nSV = 798, nBSV = 736
*.*
optimization finished, #iter = 1029
nu = 0.116570
obj = -964.052903, rho = -1.696981
nSV = 1369, nBSV = 1285
*.*
optimization finished, #iter = 1037
nu = 0.115469
obj = -988.079471, rho = 0.083116
nSV = 1361, nBSV = 1270
.
WARNING: using -h 0 may be faster
*
optimization finished, #iter = 1729
nu = 0.208298
obj = -1869.552978, rho = -1.113353
nSV = 2461, nBSV = 2357
*
optimization finished, #iter = 996
nu = 0.121065
obj = -1048.231062, rho = -1.377350
nSV = 1412, nBSV = 1336
*
optimization finished, #iter = 716
nu = 0.082115
obj = -657.946188, rho = -0.865324
nSV = 994, nBSV = 927
.
WARNING: using -h 0 may be faster
*
optimization finished, #iter = 1604
nu = 0.184783
obj = -1591.862243, rho = -3.574597
nSV = 2145, nBSV = 2029
*
optimization finished, #iter = 442
nu = 0.041480
obj = -333.627298, rho = -0.465312
nSV = 517, nBSV = 456
*
optimization finished, #iter = 254
nu = 0.020049
obj = -162.829377, rho = -0.707142
nSV = 271, nBSV = 232
*
optimization finished, #iter = 597
nu = 0.053195
obj = -446.871764, rho = -0.234762
nSV = 665, nBSV = 599
*
optimization finished, #iter = 798
nu = 0.076731
obj = -657.956860, rho = 0.591926
nSV = 958, nBSV = 872
*
optimization finished, #iter = 668
nu = 0.063571
obj = -532.336203, rho = 0.371520
nSV = 801, nBSV = 726
*
optimization finished, #iter = 719
nu = 0.071497
obj = -604.326858, rho = -0.106339
nSV = 882, nBSV = 811
*
optimization finished, #iter = 460
nu = 0.045012
obj = -367.136896, rho = -0.040445
nSV = 577, nBSV = 522
*
optimization finished, #iter = 669
nu = 0.063523
obj = -533.530219, rho = -0.255541
nSV = 785, nBSV = 706
*
optimization finished, #iter = 414
nu = 0.041957
obj = -359.274173, rho = 0.230633
nSV = 547, nBSV = 507
.
WARNING: using -h 0 may be faster
*
optimization finished, #iter = 1787
nu = 0.212122
obj = -1900.634380, rho = 0.620886
nSV = 2546, nBSV = 2451
*
optimization finished, #iter = 863
nu = 0.091525
obj = -803.541126, rho = 1.224210
nSV = 1124, nBSV = 1037
*
optimization finished, #iter = 631
nu = 0.063621
obj = -524.329098, rho = 1.487572
nSV = 804, nBSV = 729
*
optimization finished, #iter = 738
nu = 0.077979
obj = -654.732403, rho = 0.365663
nSV = 952, nBSV = 882
*
optimization finished, #iter = 941
nu = 0.100406
obj = -870.375094, rho = 0.791389
nSV = 1260, nBSV = 1179
*
optimization finished, #iter = 850
nu = 0.084384
obj = -682.661086, rho = 0.736140
nSV = 1038, nBSV = 941
*
optimization finished, #iter = 454
nu = 0.047322
obj = -418.640074, rho = 0.110100
nSV = 627, nBSV = 569
*
optimization finished, #iter = 687
nu = 0.070520
obj = -647.470236, rho = 2.159890
nSV = 928, nBSV = 862
*
optimization finished, #iter = 643
nu = 0.063988
obj = -604.880896, rho = 1.731693
nSV = 856, nBSV = 785
*
optimization finished, #iter = 393
nu = 0.041780
obj = -350.825923, rho = 0.382540
nSV = 553, nBSV = 510
*
optimization finished, #iter = 530
nu = 0.055946
obj = -508.787392, rho = 0.692606
nSV = 753, nBSV = 702
*
optimization finished, #iter = 863
nu = 0.101738
obj = -957.695161, rho = 0.196557
nSV = 1313, nBSV = 1255
*
optimization finished, #iter = 822
nu = 0.087065
obj = -756.780585, rho = 1.144696
nSV = 1075, nBSV = 994
*.*
optimization finished, #iter = 1013
nu = 0.106678
obj = -975.745788, rho = 1.100954
nSV = 1332, nBSV = 1247
*
optimization finished, #iter = 480
nu = 0.047037
obj = -360.918009, rho = -0.122367
nSV = 584, nBSV = 522
.
WARNING: using -h 0 may be faster
*
optimization finished, #iter = 1762
nu = 0.199810
obj = -1931.513715, rho = 1.224477
nSV = 2486, nBSV = 2399
*.*
optimization finished, #iter = 1139
nu = 0.122953
obj = -1085.691939, rho = 0.179493
nSV = 1501, nBSV = 1410
.*
optimization finished, #iter = 1316
nu = 0.137971
obj = -1298.928079, rho = -0.729953
nSV = 1724, nBSV = 1612
*.*
optimization finished, #iter = 1189
nu = 0.120689
obj = -1043.012856, rho = -1.534811
nSV = 1481, nBSV = 1382
*
optimization finished, #iter = 901
nu = 0.093352
obj = -852.031626, rho = -1.239564
nSV = 1180, nBSV = 1101
.
WARNING: using -h 0 may be faster
*
optimization finished, #iter = 1423
nu = 0.145085
obj = -1302.478706, rho = -2.489398
nSV = 1778, nBSV = 1661
*
optimization finished, #iter = 631
nu = 0.065990
obj = -543.573164, rho = -0.944850
nSV = 827, nBSV = 764
*
optimization finished, #iter = 909
nu = 0.086795
obj = -796.543442, rho = -0.413621
nSV = 1117, nBSV = 1037
.
WARNING: using -h 0 may be faster
*
optimization finished, #iter = 1599
nu = 0.174586
obj = -1627.135043, rho = -2.428896
nSV = 2149, nBSV = 2048
*
optimization finished, #iter = 451
nu = 0.040408
obj = -316.058551, rho = 0.181652
nSV = 529, nBSV = 461
*
optimization finished, #iter = 749
nu = 0.084485
obj = -721.161058, rho = 0.114232
nSV = 1035, nBSV = 962
*
optimization finished, #iter = 793
nu = 0.081188
obj = -696.361298, rho = -0.105534
nSV = 1019, nBSV = 938
Total nSV = 19599
Accuracy = 98.2906% (115/117) (classification)