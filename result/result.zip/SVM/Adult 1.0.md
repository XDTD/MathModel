              precision    recall  f1-score   support
    
       <=50k       0.91      0.96      0.93      7691
        >50k       0.69      0.52      0.59      1516
    
    accuracy                           0.88      9207
   macro avg       0.80      0.74      0.76      9207
weighted avg       0.87      0.88      0.88      9207

roc: 0.9104810680612538