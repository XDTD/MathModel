D:\Anaconda3\envs\tf\python.exe E:/CODE/GIT/MathModel/SvmTest.py
.................*.....*
optimization finished, #iter = 22195
nu = 0.955748
obj = -5650.726188, rho = 0.084754
nSV = 11344, nBSV = 5421
...............*.....*
optimization finished, #iter = 20322
nu = 0.962621
obj = -5616.329996, rho = 0.072064
nSV = 11263, nBSV = 5421
...................*....*
optimization finished, #iter = 23356
nu = 0.891392
obj = -5952.083580, rho = 0.195936
nSV = 12163, nBSV = 5421
................*......*
optimization finished, #iter = 22629
nu = 0.953562
obj = -5661.568545, rho = 0.088754
nSV = 11370, nBSV = 5421
...............*....*
optimization finished, #iter = 19620
nu = 0.952808
obj = -5665.299259, rho = 0.090131
nSV = 11379, nBSV = 5421
................*.....*
optimization finished, #iter = 21117
nu = 0.938539
obj = -5734.888541, rho = 0.115805
nSV = 11552, nBSV = 5421
................*.....*
optimization finished, #iter = 21390
nu = 0.956169
obj = -5648.630693, rho = 0.083981
nSV = 11339, nBSV = 5421
................*.....*
optimization finished, #iter = 21358
nu = 0.927777
obj = -5786.149419, rho = 0.134717
nSV = 11686, nBSV = 5421
...............*......*
optimization finished, #iter = 21312
nu = 0.961852
obj = -5620.198751, rho = 0.073492
nSV = 11272, nBSV = 5421
...........*.....*
optimization finished, #iter = 16129
nu = 0.993115
obj = -5881.946132, rho = -0.013676
nSV = 11765, nBSV = 5842
..............*.....*
optimization finished, #iter = 19532
nu = 0.935334
obj = -6282.754276, rho = 0.121477
nSV = 12665, nBSV = 5923
.........*....*
optimization finished, #iter = 13967
nu = 0.997810
obj = -5935.942476, rho = 0.004370
nSV = 11872, nBSV = 5923
..........*....*
optimization finished, #iter = 14848
nu = 0.997054
obj = -5940.397154, rho = 0.005874
nSV = 11881, nBSV = 5923
.............*......*
optimization finished, #iter = 19721
nu = 0.982744
obj = -6023.471139, rho = 0.033926
nSV = 12054, nBSV = 5923
......*.....*
optimization finished, #iter = 11033
nu = 0.999578
obj = -5920.497559, rho = -0.000977
nSV = 11841, nBSV = 6721
................*.*
optimization finished, #iter = 17078
nu = 0.971940
obj = -6084.665012, rho = 0.054589
nSV = 12188, nBSV = 5923
...........*.....*
optimization finished, #iter = 16321
nu = 0.993885
obj = -5886.561686, rho = -0.012156
nSV = 11774, nBSV = 5851
.................*.....*
optimization finished, #iter = 22070
nu = 0.928481
obj = -6231.928123, rho = 0.133492
nSV = 12584, nBSV = 5842
............*.....*
optimization finished, #iter = 17977
nu = 0.990925
obj = -5894.537047, rho = 0.017986
nSV = 11791, nBSV = 5842
.............*...*
optimization finished, #iter = 16364
nu = 0.990169
obj = -5898.870594, rho = 0.019470
nSV = 11800, nBSV = 5842
..............*..*
optimization finished, #iter = 16243
nu = 0.975862
obj = -5979.688057, rho = 0.047137
nSV = 11973, nBSV = 5842
...........*.......*
optimization finished, #iter = 18008
nu = 0.993537
obj = -5879.511637, rho = 0.012842
nSV = 11760, nBSV = 5842
...............*......*
optimization finished, #iter = 21928
nu = 0.965062
obj = -6039.219596, rho = 0.067518
nSV = 12107, nBSV = 5842
......*.....*
optimization finished, #iter = 11684
nu = 0.999230
obj = -5846.492396, rho = 0.001538
nSV = 11693, nBSV = 5842
.................*...*
optimization finished, #iter = 20088
nu = 0.937515
obj = -6298.862526, rho = -0.117621
nSV = 12691, nBSV = 5949
.................*......*
optimization finished, #iter = 23164
nu = 0.938268
obj = -6304.415672, rho = -0.116286
nSV = 12700, nBSV = 5958
.................*.......*
optimization finished, #iter = 24064
nu = 0.952536
obj = -6408.813267, rho = -0.090626
nSV = 12873, nBSV = 6131
.............*........*
optimization finished, #iter = 21136
nu = 0.934913
obj = -6279.645388, rho = -0.122219
nSV = 12660, nBSV = 5918
..................*...*
optimization finished, #iter = 21028
nu = 0.963327
obj = -6486.625206, rho = -0.070751
nSV = 13007, nBSV = 6265
.................*....*
optimization finished, #iter = 21454
nu = 0.929246
obj = -6237.623512, rho = -0.132157
nSV = 12593, nBSV = 5851
.......*....*
optimization finished, #iter = 11898
nu = 0.999244
obj = -5953.492498, rho = 0.001511
nSV = 11907, nBSV = 5949
............*.....*
optimization finished, #iter = 17415
nu = 0.984934
obj = -6037.297946, rho = 0.029685
nSV = 12080, nBSV = 5949
.........*......*
optimization finished, #iter = 15798
nu = 0.997388
obj = -5933.418597, rho = -0.005211
nSV = 11867, nBSV = 5918
...............*.....*
optimization finished, #iter = 20250
nu = 0.974128
obj = -6099.029966, rho = 0.050439
nSV = 12214, nBSV = 5949
............*....*
optimization finished, #iter = 16547
nu = 0.991695
obj = -5899.192482, rho = -0.016473
nSV = 11800, nBSV = 5851
.............*......*
optimization finished, #iter = 19599
nu = 0.985689
obj = -6042.058931, rho = 0.028217
nSV = 12089, nBSV = 5958
..........*......*
optimization finished, #iter = 16118
nu = 0.996632
obj = -5937.865416, rho = -0.006714
nSV = 11876, nBSV = 5918
...............*.....*
optimization finished, #iter = 20593
nu = 0.974883
obj = -6103.977695, rho = 0.049002
nSV = 12223, nBSV = 5958
............*.....*
optimization finished, #iter = 17932
nu = 0.990939
obj = -5903.538515, rho = -0.017959
nSV = 11809, nBSV = 5851
.............*.....*
optimization finished, #iter = 18584
nu = 0.982322
obj = -6020.799318, rho = -0.034741
nSV = 12049, nBSV = 5918
..............*.....*
optimization finished, #iter = 19502
nu = 0.989190
obj = -6196.566695, rho = 0.021389
nSV = 12396, nBSV = 6131
...............*.....*
optimization finished, #iter = 20189
nu = 0.976632
obj = -5984.605739, rho = -0.045670
nSV = 11982, nBSV = 5851
................*....*
optimization finished, #iter = 20041
nu = 0.971518
obj = -6081.889736, rho = 0.055387
nSV = 12183, nBSV = 5918
...........*.....*
optimization finished, #iter = 16166
nu = 0.994307
obj = -5884.120052, rho = -0.011321
nSV = 11769, nBSV = 5851
..............*....*
optimization finished, #iter = 18650
nu = 0.965830
obj = -6044.320486, rho = -0.066081
nSV = 12116, nBSV = 5851
Total nSV = 60000
Accuracy = 12.8205% (15/117) (classification)
*
optimization finished, #iter = 182
nu = 0.130140
obj = -107.705875, rho = 0.451831
nSV = 175, nBSV = 146
*
optimization finished, #iter = 155
nu = 0.081031
obj = -71.903809, rho = 0.466884
nSV = 122, nBSV = 95
*
optimization finished, #iter = 75
nu = 0.037008
obj = -29.134798, rho = 0.284603
nSV = 58, nBSV = 40
*
optimization finished, #iter = 127
nu = 0.051538
obj = -40.382130, rho = -0.165007
nSV = 87, nBSV = 55
*
optimization finished, #iter = 75
nu = 0.033334
obj = -34.560558, rho = -0.052446
nSV = 62, nBSV = 50
*
optimization finished, #iter = 204
nu = 0.075347
obj = -89.193843, rho = 0.406484
nSV = 161, nBSV = 120
*
optimization finished, #iter = 140
nu = 0.089429
obj = -68.004842, rho = 0.067878
nSV = 121, nBSV = 94
*
optimization finished, #iter = 232
nu = 0.110520
obj = -98.520637, rho = 1.178456
nSV = 176, nBSV = 135
*
optimization finished, #iter = 100
nu = 0.041915
obj = -31.902453, rho = -0.006858
nSV = 68, nBSV = 43
*
optimization finished, #iter = 199
nu = 0.096160
obj = -78.261294, rho = 0.113367
nSV = 137, nBSV = 100
*
optimization finished, #iter = 135
nu = 0.068801
obj = -49.698111, rho = 0.030712
nSV = 94, nBSV = 65
*
optimization finished, #iter = 265
nu = 0.179664
obj = -152.734966, rho = -1.532626
nSV = 245, nBSV = 197
*
optimization finished, #iter = 119
nu = 0.027997
obj = -26.001749, rho = -0.875420
nSV = 58, nBSV = 33
*
optimization finished, #iter = 264
nu = 0.099371
obj = -113.312437, rho = 0.042156
nSV = 203, nBSV = 153
*
optimization finished, #iter = 196
nu = 0.148868
obj = -107.753086, rho = -1.512226
nSV = 178, nBSV = 145
*
optimization finished, #iter = 238
nu = 0.119460
obj = -100.200168, rho = -0.001297
nSV = 175, nBSV = 127
*
optimization finished, #iter = 168
nu = 0.081618
obj = -60.329407, rho = -0.547603
nSV = 115, nBSV = 86
*
optimization finished, #iter = 189
nu = 0.090773
obj = -76.569161, rho = 0.347816
nSV = 132, nBSV = 103
*
optimization finished, #iter = 161
nu = 0.058361
obj = -45.620989, rho = -0.555660
nSV = 97, nBSV = 59
*
optimization finished, #iter = 110
nu = 0.049154
obj = -53.122833, rho = 0.011854
nSV = 90, nBSV = 74
*
optimization finished, #iter = 145
nu = 0.045493
obj = -53.360057, rho = -0.051441
nSV = 102, nBSV = 68
*
optimization finished, #iter = 237
nu = 0.116606
obj = -90.675493, rho = -0.660523
nSV = 160, nBSV = 119
*
optimization finished, #iter = 258
nu = 0.129509
obj = -124.139937, rho = 0.036039
nSV = 204, nBSV = 160
*
optimization finished, #iter = 252
nu = 0.169535
obj = -142.727929, rho = -0.295899
nSV = 238, nBSV = 202
*
optimization finished, #iter = 116
nu = 0.067762
obj = -55.971894, rho = -0.739626
nSV = 101, nBSV = 76
*
optimization finished, #iter = 67
nu = 0.030549
obj = -32.028209, rho = -0.466743
nSV = 60, nBSV = 45
*
optimization finished, #iter = 116
nu = 0.030985
obj = -33.533943, rho = -0.242271
nSV = 70, nBSV = 44
*
optimization finished, #iter = 131
nu = 0.082610
obj = -64.573120, rho = -0.826253
nSV = 112, nBSV = 85
*
optimization finished, #iter = 143
nu = 0.066295
obj = -59.457306, rho = 0.107008
nSV = 108, nBSV = 79
*
optimization finished, #iter = 270
nu = 0.198321
obj = -182.060214, rho = -1.366208
nSV = 269, nBSV = 239
*
optimization finished, #iter = 72
nu = 0.024203
obj = -25.403409, rho = -0.231081
nSV = 48, nBSV = 34
*
optimization finished, #iter = 214
nu = 0.060004
obj = -68.907235, rho = 0.453985
nSV = 133, nBSV = 90
*
optimization finished, #iter = 220
nu = 0.140709
obj = -115.075942, rho = -0.308796
nSV = 191, nBSV = 153
*
optimization finished, #iter = 210
nu = 0.107922
obj = -100.299220, rho = 1.019851
nSV = 173, nBSV = 133
*
optimization finished, #iter = 231
nu = 0.067364
obj = -55.105816, rho = 0.298924
nSV = 110, nBSV = 72
*
optimization finished, #iter = 52
nu = 0.013795
obj = -17.576699, rho = 0.268962
nSV = 42, nBSV = 24
*
optimization finished, #iter = 96
nu = 0.052093
obj = -53.016234, rho = -0.397155
nSV = 89, nBSV = 73
*
optimization finished, #iter = 67
nu = 0.030099
obj = -31.969479, rho = 0.809682
nSV = 60, nBSV = 44
*
optimization finished, #iter = 61
nu = 0.038335
obj = -38.627654, rho = -0.120922
nSV = 71, nBSV = 57
*
optimization finished, #iter = 167
nu = 0.059409
obj = -64.468516, rho = -0.548176
nSV = 123, nBSV = 90
*
optimization finished, #iter = 240
nu = 0.072607
obj = -89.104453, rho = 0.342350
nSV = 163, nBSV = 119
*
optimization finished, #iter = 103
nu = 0.032618
obj = -35.344783, rho = -0.206759
nSV = 69, nBSV = 51
*
optimization finished, #iter = 227
nu = 0.125140
obj = -106.056866, rho = 1.414836
nSV = 179, nBSV = 135
*
optimization finished, #iter = 225
nu = 0.115392
obj = -85.988976, rho = 0.355460
nSV = 159, nBSV = 122
*
optimization finished, #iter = 142
nu = 0.068740
obj = -60.828812, rho = -0.731793
nSV = 111, nBSV = 82
Total nSV = 2059
Accuracy = 98.2906% (115/117) (classification)

Process finished with exit code 0