              precision    recall  f1-score   support
    
       <=50k       0.86      0.98      0.92      7691
        >50k       0.67      0.20      0.30      1516
    
    accuracy                           0.85      9207
   macro avg       0.77      0.59      0.61      9207
weighted avg       0.83      0.85      0.82      9207

roc: 0.8979789196089456

